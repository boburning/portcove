#!/bin/sh
exec ./game "$@"
