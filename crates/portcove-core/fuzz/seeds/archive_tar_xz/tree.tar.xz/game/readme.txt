Follow the upstream setup instructions.
